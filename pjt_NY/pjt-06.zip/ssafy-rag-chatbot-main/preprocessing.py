import json, os, re
import pandas as pd


def load_json_files_and_merge(base_directory):  
    all_data = []
    
    # 디렉토리 내의 모든 JSON 파일 순회
    for filename in os.listdir(base_directory):
        if filename.endswith('.json'):
            file_path = os.path.join(base_directory, filename)
            
            # JSON 파일을 한 줄씩 읽어서 각 줄을 별도의 JSON 객체로 처리
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()  # 줄바꿈 문자 제거
                    if not line:  # 빈 줄은 건너뜀
                        continue
                    try:
                        data = json.loads(line)  # 각 줄을 JSON 객체로 변환
                        
                        # 데이터의 'SJML' 키와 'text' 키가 있는 경우 처리
                        if 'SJML' in data and 'text' in data['SJML']:
                            if isinstance(data['SJML']['text'], list):  # 다차원 배열 확인
                                for text_item in data['SJML']['text']:
                                    all_data.append(text_item)
                            else:
                                all_data.append(data['SJML']['text'])
                        else:
                            all_data.append(data)  # 'SJML.text'가 없을 경우 기본 데이터를 리스트에 추가
                        
                    except json.JSONDecodeError as e:
                        print(f"Error decoding JSON in file {filename}: {e}")

    return all_data

if __name__ == "__main__":
    # 데이터 로드 및 병합
    base_directory = 'data'
    merged_data_list = load_json_files_and_merge(base_directory)
    print(f"Total articles loaded: {len(merged_data_list)}")
    if merged_data_list:
        print("Sample article:", merged_data_list[0])
